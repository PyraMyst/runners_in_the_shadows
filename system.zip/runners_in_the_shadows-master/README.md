# FoundryVTT Runners in the Shadows 

<p align="center">


## Credits
- This work is based on Blades in the Dark (found at http://www.bladesinthedark.com/), product of One Seven Design, developed and authored by John Harper, and licensed for our use under the Creative Commons Attribution 3.0 Unported license (http://creativecommons.org/licenses/by/3.0/).
- This game system for FoundryVTT was based on a system by Dez384 (https://github.com/Dez384/foundryvtt-blades-in-the-dark/) that was originally made and maintained by Megastruktur (https://github.com/megastruktur/foundryvtt-blades-in-the-dark_)
- Some assets were taken from here (thank you  timdenee and joesinghaus): https://github.com/joesinghaus/Blades-in-the-Dark

