# How to build CSS

Install nodeJS: https://nodejs.org/en/
Install sass (https://www.npmjs.com/package/sass): npm install -g sass
Open a shell in this folder and run: sass style.scss ../styles/blades.css
